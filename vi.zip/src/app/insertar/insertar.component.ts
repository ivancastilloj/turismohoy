import { Component, OnInit , ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormsModule }   from '@angular/forms';
import { AngularFireDatabase } from 'angularfire2/database';


import { ModelService } from '../model.service';
import { model } from '../model';


@Component({
  selector: 'app-insertar',
  templateUrl: './insertar.component.html',
  styleUrls: ['./insertar.component.css'],
  encapsulation: ViewEncapsulation.None,
  providers: [AngularFireDatabase]
})
export class InsertarComponent implements OnInit {
  model: model = new model();
  submitted = false;

 
  constructor(private insertarService: ModelService, private http: HttpClient, private router: Router) {}
 
  ngOnInit() {
  }
 
  newInsertar(): void {
    this.submitted = false;
    this.model = new model();
  }
 
  save() {
    this.insertarService.createinsertar(this.model);
    this.model= new model();
  }
 
  onSubmit() {
    this.submitted = true;
    this.save();
  }
}
  