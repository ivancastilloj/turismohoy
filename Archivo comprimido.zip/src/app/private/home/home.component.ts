
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ModelService } from '../../model.service';
import { AngularFireDatabase } from 'angularfire2/database';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})

export class HomeComponent implements OnInit {
  rutas: any;
  model: any;
  
   coursesObservable: Observable<any[]>;

  constructor(private http: HttpClient,private RutasService:ModelService , private db: AngularFireDatabase,private route: ActivatedRoute) { }

  ngOnInit() {
    this.coursesObservable = this.getRutas('/rutas');
  }

  getRutas(listPath3): Observable<any[]> {
    return this.db.list(listPath3).valueChanges();
  }
}
