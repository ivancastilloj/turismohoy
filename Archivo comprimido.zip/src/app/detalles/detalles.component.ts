
import * as pdfMake from 'pdfmake/build/pdfmake';
import * as pdfFonts from 'pdfmake/build/vfs_fonts';
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ModelService } from '../model.service';
import { AngularFireDatabase } from 'angularfire2/database';
import { Observable } from 'rxjs/Observable';
@Component({
  selector: 'app-detalles',
  templateUrl: './detalles.component.html',
  styleUrls: ['./detalles.component.css']
})
export class DetallesComponent implements OnInit {

  rutas: any;
  model: any;
category:any;
   categoria: any;
  private sub: any;
   coursesObservable: Observable<any[]>;
   constructor(private http: HttpClient,private RutasService:ModelService , private db: AngularFireDatabase,private route: ActivatedRoute) { 
 
    this.route.queryParams.subscribe(params => {
      
      this.category = this.route.snapshot.params.categoria;
      console.log(this.category);

      pdfMake.vfs = pdfFonts.pdfMake.vfs;
    
  });
   }
 
  
   ngOnInit() {
    this.coursesObservable = this.getRutas('/rutas');
     
        
        var dd = { content: ''};
        pdfMake.createPdf(dd).open();
       console.log(this.category);
     
     
   }
 
   getRutas(listPath3): Observable<any[]> {
     return this.db.list(listPath3).valueChanges();
   }
 }
