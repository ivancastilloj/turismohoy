
import {Injectable} from '@angular/core';
import {AngularFireDatabase, AngularFireList} from 'angularfire2/database';



import { QueryFn } from 'angularfire2/database/interfaces';

import { model} from './model';
 
@Injectable()
export class ModelService { 
 

  private dbPath3 = '/rutas';

  insertarRef: AngularFireList<model> = null;

  constructor(private db: AngularFireDatabase) {
  
    this.insertarRef = db.list(this.dbPath3);
  }
 
  createinsertar(model: model): void {
    this.insertarRef.push(model);
  }

 
 
  getRutas(): AngularFireList<model> {
    return this.insertarRef;
  }
 
 
  private handleError(error) {
    console.log(error);
  }
}