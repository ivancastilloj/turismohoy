
export class model{
  nombre: string;
  origen:string;
  
  destino:string;
  
  categoria:string;
  fechaentrada: Date;
  fechaultima: Date;
  foto: string;
  precio:number;
  descripcion: string;
  
  }